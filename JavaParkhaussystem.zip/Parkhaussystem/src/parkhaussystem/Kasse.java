package parkhaussystem;

import java.time.Duration;
import java.time.LocalDateTime;

class Kasse {
    private String id;
    private static final double PREIS_PRO_MINUTE = 0.05;

    public Kasse(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void abrechnen(Ticket ticket) {
        if (ticket == null) {
            Display.zeigeText("Kein Ticket gefunden.");
            return;
        }
        if (ticket.bezahlt) {
            Display.zeigeText("Ticket wurde bereits bezahlt.");
            return;
        }

        LocalDateTime start = ticket.getStartDatum();
        LocalDateTime jetzt = LocalDateTime.now();
        long minuten = Duration.between(start, jetzt).toMinutes();
        if (minuten < 1) minuten = 1; // Mindestens 1 Minute berechnen

        double betrag = minuten * PREIS_PRO_MINUTE;

        Display.zeigeText("Ticket-ID: " + ticket.getId());
        Display.zeigeText("Parkdauer: " + minuten + " Minuten");
        Display.zeigeText("Zu zahlender Betrag: " + String.format("%.2f", betrag) + " CHF");
        Display.zeigeText("Bitte bestätigen Sie die Zahlung mit 'ja':");

        String eingabe = Display.leseEingabe();
        if (eingabe.trim().equalsIgnoreCase("ja")) {
            ticket.bezahlt = true;
            Display.zeigeText("Zahlung erfolgreich. Gute Fahrt!");
        } else {
            Display.zeigeText("Zahlung abgebrochen.");
        }
    }

    public void abrechnenMitId(Parkhaus parkhaus) {
        Display.zeigeText("Bitte geben Sie Ihre Ticket-ID ein:");
        String eingabe = Display.leseEingabe();
        int ticketId;
        try {
            ticketId = Integer.parseInt(eingabe.trim());
        } catch (NumberFormatException e) {
            Display.zeigeText("Ungültige Ticket-ID.");
            return;
        }

        Ticket ticket = parkhaus.findeTicketNachId(ticketId);
        abrechnen(ticket);
    }
    // Weitere Methoden für die Kasse können hier hinzugefügt werden
}