package parkhaussystem;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Parkhaus parkhaus = new Parkhaus(3);
        Einfahrtsschranke einfahrt = new Einfahrtsschranke(parkhaus);
        Ausfahrtsschranke ausfahrt = new Ausfahrtsschranke();
        Scanner scanner = new Scanner(System.in);

        Display.zeigeText("Willkommen im Parkhaus!");
        boolean running = true;
        while (running) {
            Display.zeigeText("\nWas möchten Sie tun?");
            Display.zeigeText("1: Einfahren");
            Display.zeigeText("2: Ticket bezahlen");
            Display.zeigeText("3: Ausfahren");
            Display.zeigeText("0: Beenden");
            String eingabe = scanner.nextLine();

            switch (eingabe) {
                case "1":
                    if (einfahrt.EinfahrtsschrankeOeffnen()) {
                        Ticket ticket = einfahrt.ticketDrucken();
                        einfahrt.EinfahrtsschrankeSchliessen();
                        Display.zeigeText("Ihre Ticket-ID: " + ticket.getId());

                        // Stockwerk wählen
                        Display.zeigeText("Wählen Sie ein Stockwerk (1-" + parkhaus.getAnzahlStockwerke() + "):");
                        int stockwerkNr = -1;
                        while (true) {
                            String stockwerkStr = scanner.nextLine();
                            try {
                                stockwerkNr = Integer.parseInt(stockwerkStr.trim());
                                if (stockwerkNr >= 1 && stockwerkNr <= parkhaus.getAnzahlStockwerke()) {
                                    break;
                                }
                            } catch (NumberFormatException e) {}
                            Display.zeigeText("Ungültige Eingabe. Bitte Stockwerk zwischen 1 und " + parkhaus.getAnzahlStockwerke() + " wählen:");
                        }
                        Stockwerk stockwerk = parkhaus.getStockwerk(stockwerkNr - 1);

                        // Freie Parkplätze anzeigen
                        Display.zeigeText("Freie Parkplätze auf Stockwerk " + stockwerkNr + ":");
                        boolean freiGefunden = false;
                        for (Parkplatz p : stockwerk.getParkplaetze()) {
                            if (!p.istBesetzt()) {
                                Display.zeigeText(p.getId());
                                freiGefunden = true;
                            }
                        }
                        if (!freiGefunden) {
                            Display.zeigeText("Keine freien Parkplätze auf diesem Stockwerk.");
                            break;
                        }

                        // Parkplatz wählen
                        Display.zeigeText("Bitte geben Sie die Parkplatz-ID ein:");
                        Parkplatz parkplatz = null;
                        while (parkplatz == null) {
                            String parkplatzId = scanner.nextLine();
                            parkplatz = stockwerk.findeParkplatz(parkplatzId);
                            if (parkplatz == null || parkplatz.istBesetzt()) {
                                Display.zeigeText("Ungültige oder belegte Parkplatz-ID. Bitte erneut eingeben:");
                                parkplatz = null;
                            }
                        }
                        parkplatz.besetzen();
                        Display.zeigeText("Sie haben auf Parkplatz " + parkplatz.getId() + " geparkt.");
                    } else {
                        Display.zeigeText("Einfahrtsschranke ist bereits offen.");
                    }
                    break;
                case "2":
                    Display.zeigeText("Kasse auf Stockwerk 1 wird verwendet.");
                    parkhaus.getKassen().get(0).abrechnenMitId(parkhaus);
                    break;
                case "3":
                    Display.zeigeText("Bitte geben Sie Ihre Ticket-ID ein:");
                    String ticketIdStr = scanner.nextLine();
                    int ticketId;
                    try {
                        ticketId = Integer.parseInt(ticketIdStr.trim());
                    } catch (NumberFormatException e) {
                        Display.zeigeText("Ungültige Ticket-ID.");
                        break;
                    }
                    Ticket ticket = parkhaus.findeTicketNachId(ticketId);
                    if (ticket == null) {
                        Display.zeigeText("Ticket nicht gefunden.");
                        break;
                    }
                    if (!ticket.bezahlt) {
                        Display.zeigeText("Bitte bezahlen Sie Ihr Ticket zuerst an der Kasse.");
                        break;
                    }
                    if (ausfahrt.AusfahrtsschrankeOeffnen()) {
                        ticket.setAusfahrtszeit(java.time.LocalDateTime.now());
                        Display.zeigeText("Gute Fahrt! Schranke öffnet.");
                        ausfahrt.AusfahrtsschrankeSchliessen();
                    } else {
                        Display.zeigeText("Ausfahrtsschranke ist bereits offen.");
                    }
                    break;
                case "0":
                    running = false;
                    Display.zeigeText("Auf Wiedersehen!");
                    break;
                default:
                    Display.zeigeText("Ungültige Eingabe.");
            }
        }
        scanner.close();
    }
}
