package parkhaussystem;

import java.util.ArrayList;
import java.util.List;

public class Parkhaus{

    int anzahlStockwerke;
    private List<Stockwerk> stockwerke = new ArrayList<>();
    private List<Kasse> kassen = new ArrayList<>();
    public List<Ticket> tickets = new ArrayList<>();
      
    public Parkhaus(int anzahlStockwerke) {
        // Initialize the parking house with a default number of floors
        stockwerkeErstellen(anzahlStockwerke); // Standartmäßig 3 Stockwerke
    }

    public void stockwerkeErstellen(int anzahlStockwerke) {
        this.anzahlStockwerke = anzahlStockwerke;
        
        for (int i = 0; i < anzahlStockwerke; i++) {
            Stockwerk stockwerk = new Stockwerk(i + 1, 10); // stockwerk hat 10 parkplätze
            stockwerke.add(stockwerk);
            kassen.add(new Kasse(Integer.toString(i+1)));
            
        }
    }

    public int getAnzahlStockwerke() {
        return anzahlStockwerke;
    }

    public Ticket findeTicketNachId(int id) {
        for (Ticket ticket : tickets) {
            if (ticket.getId() == id) {
                return ticket;
            }
        }
        return null;
    }

    public List<Kasse> getKassen() {
        return kassen;
    }

    public void abrechnenMitId(int id) {
        Kasse kasse = kassen.get(0);
        Ticket ticket = findeTicketNachId(id);
        if (ticket != null) {
            kasse.abrechnen(ticket);
        }
    }

    public Stockwerk getStockwerk(int index) {
        return stockwerke.get(index);
    }
}















