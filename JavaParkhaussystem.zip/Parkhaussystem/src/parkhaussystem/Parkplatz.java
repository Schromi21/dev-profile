package parkhaussystem;

class Parkplatz{


    public Parkplatz(String id) {
        this.id = id;
        this.besetzt = false;
    }
    private String id;
    private int hoehe;
    private boolean besetzt;

    public int getHoehe() {
        return hoehe;
    }

    public boolean istBesetzt(){
       return besetzt;
    }
    public void besetzen() {
        this.besetzt = true;
    }

    public void freigeben() {
        this.besetzt = false;
    }
    public String getId() {
        return this.id;
    }
}