package parkhaussystem;

public class Ausfahrtsschranke {
    private boolean geoffnet;
    private char id;


    public Ausfahrtsschranke() {
        this.geoffnet = false; 
    }

    public boolean istGeoeffnet() {
        return geoffnet;
    }

    public boolean AusfahrtsschrankeOeffnen() {
        if (!geoffnet) {
            geoffnet = true; // Öffne die Schranke
            return true; // Erfolg
        }
        return false; // Schranke ist bereits offen
    }

    public boolean AusfahrtsschrankeSchliessen() {
        if (geoffnet) {
            geoffnet = false; // Schließe die Schranke
            return true; // Erfolg
        }
        return false; // Schranke ist bereits geschlossen
    }
}