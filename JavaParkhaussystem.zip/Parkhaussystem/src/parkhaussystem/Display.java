package parkhaussystem;

import java.util.Scanner;

public class Display {
    private static Scanner scanner = new Scanner(System.in);

    public static void zeigeText(String text) {
        System.out.println(text);
    }

    public static String leseEingabe() {
        return scanner.nextLine();
    }
}
