package parkhaussystem;

import java.util.ArrayList;
import java.util.List;

class Stockwerk {

    private int hoehe;
    int anzahlParkplaetze;
    private List<Parkplatz> parkplaetze = new ArrayList<>();
    

    public Stockwerk(int hoehe, int anzahlParkplaetze) {
        this.anzahlParkplaetze = anzahlParkplaetze;
        this.hoehe = hoehe;

        for (int i = 0; i < anzahlParkplaetze; i++) {
            // ID z. B. "1-1", "1-2", ...
            String id = hoehe + "-" + (i + 1);
            parkplaetze.add(new Parkplatz(id));
        }


    }

        public int getHoehe() {
        return hoehe;
    }

    public Parkplatz findeParkplatz(String id) {
    for (Parkplatz p : parkplaetze) {
        if (p.getId().equals(id)) {
            return p;
        }
    }
    return null;
}

    public List<Parkplatz> getParkplaetze() {
        return parkplaetze;
    }
}
