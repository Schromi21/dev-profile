package parkhaussystem;

import java.time.LocalDateTime;

public class Einfahrtsschranke{
    private boolean geoffnet;
    private Parkhaus parkhaus;

    public Einfahrtsschranke(Parkhaus parkhaus) {
        this.parkhaus = parkhaus;
        this.geoffnet = false; 
    }

    public boolean istGeoeffnet() {
        return geoffnet;
    }

    public boolean EinfahrtsschrankeOeffnen() {
        if (!geoffnet) {
            geoffnet = true; // Öffne die Schranke
            ticketDrucken();
            return true; // Erfolg
        }
        return false; // Schranke ist bereits offen
    }

    public boolean EinfahrtsschrankeSchliessen() {
        if (geoffnet) {
            geoffnet = false; // Schließe die Schranke
            return true; // Erfolg
        }
        return false; // Schranke ist bereits geschlossen
    }

    public Ticket ticketDrucken() {
        LocalDateTime eintrittszeit = LocalDateTime.now();
        Ticket ticket = new Ticket(eintrittszeit);
        parkhaus.tickets.add(ticket); // Ticket zur Parkhaus-Liste hinzufügen
        System.out.println("Ticket gedruckt mit Eintrittszeit: " + eintrittszeit);
        return ticket;
    }
}