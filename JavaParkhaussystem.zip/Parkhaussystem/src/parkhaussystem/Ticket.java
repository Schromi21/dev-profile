package parkhaussystem;

import java.time.LocalDateTime;

class Ticket{
    
    LocalDateTime eintrittszeit;
    LocalDateTime ausfahrtszeit;
    boolean bezahlt;
    String ticketId;
    private static int counter = 1;
    private int id;
    private LocalDateTime startDatum;

    public Ticket(LocalDateTime eintrittszeit) {
        this.bezahlt = false; // Ticket is created as unpaid
        this.eintrittszeit = eintrittszeit;
        this.ausfahrtszeit = null; // Ticket is created when the car enters
        this.id = counter++;
        this.startDatum = eintrittszeit;
    }

    public LocalDateTime getEintrittszeit() {
        return eintrittszeit;
    }

    public LocalDateTime getAusfahrtszeit() {
        return ausfahrtszeit;
    }

    public void setAusfahrtszeit(LocalDateTime ausfahrtszeit) {
        this.ausfahrtszeit = ausfahrtszeit; // Set the exit time when the car leaves
    }

    public int getId() {
        return id;
    }

    public LocalDateTime getStartDatum() {
        return startDatum;
    }


};