<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bücherliste</title>
    <script src="./script.js"></script>
    <link rel="stylesheet" href="./indexdesign.css">

</head>

<style>
body {
    
    background: #101114FF;
  }


  .pagination {
    text-align: center;
    margin: 20px 0;
}

.pagination a {
    display: inline-block;
    padding: 8px 12px;
    margin: 0 5px;
    background-color: #E04B00FF;
    color: white;
    text-decoration: none;
    border-radius: 5px;
}

.pagination a:hover {
    background-color:rgb(255, 85, 0);
}

.pagination .current-page {
    display: inline-block;
    padding: 8px 12px;
    margin: 0 5px;
    background-color: #343a40;
    color: white;
    border-radius: 5px;
}

.sort-container {
    position: relative; /* Stellt sicher, dass es sich unter dem Header befindet */
    width: 50%;
    text-align: center;
    margin-top: 85px; /* Abstand zum Header */
    padding: 30px;
    background-color: #1d1e23;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    z-index: 5;
    margin-bottom:20px;
    margin-left: 23%;
    border-radius: 5px;
}

#options{
 
  color: #FFFFFF;	
  width: 397px; 
  height: 39px; 
  background: #34363CFF; 
  border-radius: 4px; /* border-s */
  border-width: 1px; 
  border-color: #34363CFF; 
  border-style: solid; 
  box-shadow: 0px 0px 1px #171a1f12, 0px 0px 2px #171a1f1F;
}
     
     /* Mehr Infos Button */
     .info-button {
        position: fixed;
        top: 20px;
        right: 40.5%;
        background-color: #E04B00FF;
        color: white;
        border: none;
        padding: 8px 15px;
        cursor: pointer;
        font-size: 14px;
        margin-left: 15px;
        border-radius: 5px;
        display: flex; /* Flexbox für zentriertes Chevron */
        align-items: center; /* Vertikal zentrieren */
        justify-content: center; /* Horizontal zentrieren */
        transition: transform 0.3s ease; /* Sanfte Drehung */
    }

    /* Chevron drehen, wenn aktiv */
    .info-button.active {
        transform: rotate(180deg); /* Chevron zeigt nach unten */
    }

    /* Versteckter Container */
    .info-container {
        width: 80%;
        max-width: 1000px;
        background: #1d1e23; /* Gleiche Farbe wie der Header */
        padding: 15px;
        margin: 80px auto 20px;
        border-radius: 10px;
        box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.2);
        display: none; /* Standardmäßig versteckt */
        transition: opacity 0.3s ease-in-out;
    }

    /* Wenn aktiv, wird der Container sichtbar */
    .info-container.active {
        display: block;
        opacity: 1;
    }
    
    /* Info-Box mit Chevron-Bild */
    .info-box {
        position: fixed;
        top: 20px;
        right: 40.5%;
        width: 40px; /* Breite des Kästchens */
        height: 40px; /* Höhe des Kästchens */
        background-color: #E04B00FF; /* Orange Hintergrundfarbe */
        background-image: url('chevron.png'); /* Chevron-Bild */
        background-size: 50%; /* Bildgröße anpassen */
        background-repeat: no-repeat; /* Bild nicht wiederholen */
        background-position: center; /* Bild zentrieren */
        border-radius: 5px; /* Abgerundete Ecken */
        cursor: pointer; /* Zeigt den Mauszeiger als Hand an */
        transition: transform 0.3s ease; /* Sanfte Drehung */
    }

    /* Chevron drehen, wenn aktiv */
    .info-box.active {
        transform: rotate(180deg); /* Chevron zeigt nach unten */
    }
    
    
    /* Hamburger-Icon */
    .menu-icon {
        position: fixed; /* Fixiere das Symbol */
        top: 20px; /* Abstand vom oberen Rand */
        right: 20px; /* Abstand vom rechten Rand */
        font-size: 30px;
        cursor: pointer;
        z-index: 1100; /* Höher als das Menü */
        color: white;
        transition: opacity 0.3s ease-in-out; /* Sanfte Animation */
        color: #E04B00FF
    }

    /* Ausblenden des Hamburger-Icons, wenn das Menü aktiv ist */
    .menu-icon.hidden {
        opacity: 0; /* Unsichtbar */
        pointer-events: none; /* Klicks deaktivieren */
    }

    /* Menü-Hintergrundfarbe an den Header anpassen */
    .menu {
        position: fixed;
        top: 0;
        right: -250px; /* Menü ragt 50px heraus */
        width: 30%; /* Nimmt bis zu 1/3 des Bildschirms ein */
        max-width: 300px;
        height: 100%;
        background: #1d1e23; /* Gleiche Farbe wie der Header */
        color: white;
        padding: 20px;
        box-shadow: -2px 0 5px rgba(0, 0, 0, 0.5);
        transition: right 0.3s ease-in-out;
        z-index: 1000; /* Unter dem Burger-Symbol */
        text-align: center;
    }

    /* Menü anzeigen */
    .menu.active {
        right: 0; /* Menü vollständig sichtbar */
    }

    /* Menü schließen (X) */
    .close-btn {
        font-size: 25px;
        cursor: pointer;
        display: block;
        text-align: right;
    }

    /* Menü-Links */
    .menu ul {
        list-style: none;
        padding: 0;
        margin-top: 20px;
    }

    .menu ul li {
        padding: 15px 0; /* Mehr Abstand zwischen den Links */
        border-bottom: 1px solid #343a40; /* Trennlinie zwischen den Links */
    }

    .menu ul li:last-child {
        border-bottom: none; /* Keine Linie unter dem letzten Link */
    }

    .menu ul li a {
        color: white;
        text-decoration: none;
        font-size: 18px;
    }

    .menu ul li a:hover {
        text-decoration: underline;
    }

#bild {
    width: 100px;
    height: 100px;
    float: left;
    margin-right: 10px;

    
}

.header {
    background-color: #1d1e23;
    position: fixed;
    top: 0px;
    width: 100%;
    z-index: 100;
    color: white;
    text-align: center;
    margin-bottom: 10px;
    padding-bottom: 20px;
    border-bottom: 1px solid black;
}


/* Suchcontainer */
.search-container {
    
    text-align: center;
    background-color: #1d1e23; /* Grauer Hintergrund wie bei den anderen */
    padding: 20px; /* Abstand innerhalb des Containers */
    border-radius: 10px; /* Abgerundete Ecken */
    box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.2); /* Schatten */
    width: 80%; /* Breite des Containers */
    max-width: 1000px; /* Maximale Breite */
}

/* Suchfelder in einem 2x2-Layout */
.search-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr); /* Zwei Spalten */
    gap: 20px; /* Abstand zwischen den Feldern */
    justify-content: center;
    align-items: center;
    margin-bottom: 20px;
}

/* Einzelne Suchfelder */
.search-item {
    text-align: left;
    padding: 10px; /* Abstand innerhalb jedes Suchfelds */
}

/* Labels für Suchfelder */
.search-item label {
    display: block;
    font-size: 14px;
    color: white;
    margin-bottom: 5px;
}

/* Eingabefelder */
.search-container input[type="text"],
.search-container select {
    padding: 8px;
    width: 100%;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f0f0f0; /* Grauer Hintergrund */
}

/* Suchbutton */
#such-button {
    padding: 10px 20px;
    background-color: #E04B00FF;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top: 10px;
}

#such-button:hover {
    background-color: #E04B00FF;
}

/* Stil für die Container der Bücher */
.book-container {
    width: 80%;
    margin: 20px auto;
    margin-top: 20px; /* Abstand zum Header */
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 15px; /* Abstand zwischen den Boxen */
}

/* Stil für die Buch-Box */
.book-box {
    width: 650px;
    padding: 15px;
    background-color: #1d1e23; /* Gleiche Hintergrundfarbe wie das Sortierfeld */
    border-radius: 10px;
    box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.2);
    text-align: center;
    color: white; /* Weiße Schrift für besseren Kontrast */
}

.book-box h3 {
    margin: 0;
    color: white;
    position: fixed
    left:60%;
}

.book-box p {
    margin: 5px 0;
    color: #ccc; /* Hellgraue Schrift für die Details */
}

.pagination {
    text-align: center;
    margin: 20px 0;
}

.pagination a {
    margin: 0 5px;
    padding: 8px 12px;
    background-color: #E04B00FF;
    color: white;
    text-decoration: none;
    border-radius: 5px;
}

.pagination a:hover {
    background-color: #0056b3;
}

.pagination .current-page {
    margin: 0 5px;
    padding: 8px 12px;
    background-color: #34363CFF;
    color: white;
    border-radius: 5px;
}

.results-per-page {
    text-align: center;
    margin: 20px 0;
}

.results-per-page label {
    font-size: 16px;
    color: white;
    margin-right: 10px;
}

.results-per-page select {
    padding: 5px 10px;
    font-size: 14px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

/* Türkiser Knopf */
.more-button {
    background-color: #08829AFF;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
}

.more-button:hover {
    background-color: #008c9e;
}

/* Pop-up Hintergrund */
.popup {
    display: none; /* Standardmäßig versteckt */
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(16, 17, 21, 0.98); /* Halbtransparenter roter Hintergrund */
    z-index: 1000;
}

/* Pop-up Inhalt */
.popup-content {
    position: relative;
    margin: 10% auto;
    padding: 20px;
    background-color: white;
    width: 90%; /* Breiteres Pop-up */
    max-width: 800px; /* Maximale Breite erhöht */
    border-radius: 10px;
    text-align: left; /* Text linksbündig */
    color: #333;
    display: flex;
    flex-direction: column;
    gap: 20px;
}

/* Pop-up Bild links */
.popup-body {
    display: flex;
    gap: 20px;
    align-items: flex-start;
    flex-wrap: wrap; /* Ermöglicht Umbruch bei kleineren Bildschirmen */
}

/* Bild im Pop-up */
.popup-image {
    width:200px;
    border-radius: 5px;
    box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.2);
    flex-shrink: 0; /* Verhindert, dass das Bild verkleinert wird */
}

/* Zweispaltige Info-Tabelle */
.popup-info {
    display: grid;
    grid-template-columns: 1fr 1fr; /* Zwei Spalten */
    gap: 10px;
    width: calc(100% - 220px); /* Platz für das Bild reservieren */
}

/* Beschreibung am Ende */
.popup-description {
    margin-top: 20px;
    font-size: 16px;
    color: #555;
    grid-column: span 2; /* Beschreibung über beide Spalten */
}

/* Schließen-Button */
.close-popup-button {
    background-color: #E04B00FF;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
}

.close-popup-button:hover {
    background-color: #E04B00FF;
}

/* Schließen-Button */
.popup .close-btn {
    position: absolute;
    top: 10px;
    right: 20px;
    font-size: 24px;
    font-weight: bold;
    color: white;
    cursor: pointer;
}

.popup .close-btn:hover {
    color: #ffcccc;
}

/* Book.ch Button */
.book-button {
    position: fixed;
    left:5px;
    top: 5px;
    background-color: #08829AFF; /* Türkis */
    color: white; /* Weiße Schrift */
    border: 2px solid black; 
    padding: 10px 20px;
    font-size: 24px; /* Große Schrift */
    font-weight: bold;
    border-radius: 5px;
    cursor: pointer;

}

.book-button:hover {
    background-color: #008c9e; /* Dunkleres Türkis beim Hover */

}

/* Titel im Pop-up */
.popup-title {
    font-size: 24px; /* Größer als der Rest */
    font-weight: bold;
    color: white; /* Weiße Schrift */
    background-color: #1d1e23; /* Grauer Hintergrund */
    padding: 10px;
    border-radius: 5px;
    text-align: center; /* Zentriert den Titel */
    margin-bottom: 20px; /* Abstand zum Rest */
}

/* Login-Button */
.login-button {
    position: fixed;	
    right: 250px;
    top:15px;
    background-color: #08829AFF; /* Türkis */
    color: white; /* Weiße Schrift */
    border: none; /* Keine Umrandung */
    padding: 10px 20px; /* Innenabstand */
    font-size: 16px; /* Schriftgröße */
    font-weight: bold; /* Fettschrift */
    border-radius: 5px; /* Abgerundete Ecken */
    cursor: pointer; /* Zeigt den Mauszeiger als Hand an */
    margin-left: 10px; /* Abstand zum vorherigen Element */
}

.login-button:hover {
    background-color: #008c9e; /* Dunkleres Türkis beim Hover */
}

.footer {
    background-color: #1d1e23; /* Gleiche Hintergrundfarbe wie der Header */
    color: white; /* Weiße Schrift */
    text-align: center; /* Zentrierter Text */
    padding: 15px 0; /* Abstand oben und unten */
    margin-top: 20px; /* Abstand zum Inhalt */
    border-top: 1px solid #343a40; /* Trennlinie oben */
    font-size: 14px; /* Kleinere Schriftgröße */
}
</style>


<body>
    <?php
    session_start(); // Session starten

    $servername = "localhost";
    $username = "rundb";
    $password = "runpass";
    $dbname = "book";

    // Verbindung zur Datenbank
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Verbindung fehlgeschlagen: " . $conn->connect_error);
    }

    $resultsPerPage = isset($_GET['resultsPerPage']) && is_numeric($_GET['resultsPerPage']) ? (int)$_GET['resultsPerPage'] : 12; // Standard: 12 Ergebnisse
    $currentPage = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($currentPage - 1) * $resultsPerPage;

    // Standard-SQL-Abfrage
    $sql = "SELECT buecher.*, 
                   kategorien.kategorie AS kategoriename, 
                   zustaende.beschreibung AS zustand_beschreibung 
            FROM buecher 
            LEFT JOIN kategorien 
            ON buecher.kategorie = kategorien.id
            LEFT JOIN zustaende 
            ON buecher.zustand = zustaende.zustand";

    // Dynamische Filterbedingungen
    $conditions = [];
    if (!empty(trim($_GET['search'] ?? ''))) {
        $search = $conn->real_escape_string($_GET['search']);
        $conditions[] = "Title LIKE '%$search%'";
    }
    if (!empty(trim($_GET['nummer'] ?? ''))) {
        $nummer = $conn->real_escape_string($_GET['nummer']);
        $conditions[] = "Nummer = '$nummer'";
    }
    if (!empty(trim($_GET['autor'] ?? ''))) {
        $autor = $conn->real_escape_string($_GET['autor']);
        $conditions[] = "autor LIKE '%$autor%'";
    }
    if (!empty(trim($_GET['zustand'] ?? ''))) {
        $zustand = $conn->real_escape_string($_GET['zustand']);
        $conditions[] = "buecher.zustand = '$zustand'";
    }

    // Füge die Filterbedingungen zur SQL-Abfrage hinzu
    if (count($conditions) > 0) {
        $sql .= " WHERE " . implode(' AND ', $conditions);
    }

    // Sortierfunktion hinzufügen
    if (isset($_GET['sort'])) {
        switch ($_GET['sort']) {
            case 'title_asc':
                $sql .= " ORDER BY Title ASC";
                break;
            case 'zustand':
                $sql .= " ORDER BY zustaende.beschreibung ASC"; // Sortiert nach Zustandsbeschreibung
                break;
            case 'kaufer':
                $sql .= " ORDER BY kaufer DESC"; // Sortiert nach Käufer
                break;
        }
    }

    // Begrenzung der Ergebnisse
    $sql .= " LIMIT $resultsPerPage OFFSET $offset";

    // Führe die Abfrage aus
    $result = $conn->query($sql);

    // Gesamte Anzahl der Ergebnisse für die Pagination
    $totalResultsSql = "SELECT COUNT(*) as total 
                        FROM buecher 
                        LEFT JOIN kategorien 
                        ON buecher.kategorie = kategorien.id
                        LEFT JOIN zustaende 
                        ON buecher.zustand = zustaende.zustand";
    if (count($conditions) > 0) {
        $totalResultsSql .= " WHERE " . implode(' AND ', $conditions);
    }
    $totalResultsResult = $conn->query($totalResultsSql);
    $totalResults = $totalResultsResult->fetch_assoc()['total'];
    $totalPages = ceil($totalResults / $resultsPerPage);
    ?>
    <div class="header">
        <button class="book-button">Books.ch</button>
        <h2>Bücher suchen</h2>
        <button class="info-button" onclick="toggleInfo()">⌃</button>
        <button class="login-button">Login</button>
    </div>
        
    <div class="info-container" id="infoContainer">
        <div class="search-container">
            <form method="GET" action="">
                <div class="search-grid">
                    <!-- Suchfeld: Titel -->
                    <div class="search-item">
                        <label for="search">Titel:</label>
                        <input type="text" id="search" name="search" placeholder="Buchtitel eingeben..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    </div>

                    <!-- Suchfeld: Nummer -->
                    <div class="search-item">
                        <label for="nummer">Nummer:</label>
                        <input type="text" id="nummer" name="nummer" placeholder="Nummer eingeben..." value="<?php echo isset($_GET['nummer']) ? htmlspecialchars($_GET['nummer']) : ''; ?>">
                    </div>

                    <!-- Suchfeld: Autor -->
                    <div class="search-item">
                        <label for="autor">Autor:</label>
                        <input type="text" id="autor" name="autor" placeholder="Autor eingeben..." value="<?php echo isset($_GET['autor']) ? htmlspecialchars($_GET['autor']) : ''; ?>">
                    </div>

                    <!-- Suchfeld: Zustand -->
                    <div class="search-item">
                        <label for="zustand">Zustand:</label>
                        <select id="zustand" name="zustand">
                            <option value="">Zustand auswählen...</option>
                            <option value="S" <?php echo isset($_GET['zustand']) && $_GET['zustand'] === 'S' ? 'selected' : ''; ?>>S (Sehr Gut)</option>
                            <option value="M" <?php echo isset($_GET['zustand']) && $_GET['zustand'] === 'M' ? 'selected' : ''; ?>>M (Mittel)</option>
                            <option value="G" <?php echo isset($_GET['zustand']) && $_GET['zustand'] === 'G' ? 'selected' : ''; ?>>G (Gebraucht)</option>
                        </select>
                    </div>
                </div>
                <button id="such-button" type="submit">Suchen</button>
            </form>
        </div>
    </div>
    <!-- Burger-Menü-Symbol -->
    <div class="menu-icon" onclick="toggleMenu()">☰</div>

    <!-- Das Menü -->
    <div class="menu" id="menu">
        <span class="close-btn" onclick="toggleMenu()">✖</span>
        <ul>
            <li><a href="#">Startseite</a></li>
            <li><a href="#">Alle Bücher</a></li>
            <li><a href="#">Kundenliste</a></li>
            <li><a href="#">Kontakt</a></li>
        </ul>
    </div>

    <div class="info-box" onclick="toggleInfo()"></div>
    
    <div class="sort-container">
        <form method="GET" action="">
            <select id="options" name="sort" onchange="this.form.submit()">
                <option value="">Sortieren nach...</option>
                <option value="title_asc" <?php echo isset($_GET['sort']) && $_GET['sort'] === 'title_asc' ? 'selected' : ''; ?>>Titel (A-Z)</option>
                <option value="zustand" <?php echo isset($_GET['sort']) && $_GET['sort'] === 'zustand' ? 'selected' : ''; ?>>Zustand</option>
                <option value="kaufer" <?php echo isset($_GET['sort']) && $_GET['sort'] === 'kaufer' ? 'selected' : ''; ?>>Käufer</option>
            </select>
            <!-- Behalte die aktuellen Filter -->
            <input type="hidden" name="search" value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
            <input type="hidden" name="nummer" value="<?php echo htmlspecialchars($_GET['nummer'] ?? ''); ?>">
            <input type="hidden" name="autor" value="<?php echo htmlspecialchars($_GET['autor'] ?? ''); ?>">
            <input type="hidden" name="zustand" value="<?php echo htmlspecialchars($_GET['zustand'] ?? ''); ?>">
        </form>
    </div>  

<div class="results-per-page">
    <form method="GET" action="">
        <label for="resultsPerPage">Ergebnisse pro Seite:</label>
        <select id="resultsPerPage" name="resultsPerPage" onchange="this.form.submit()">
            <option value="12" <?php echo (isset($_GET['resultsPerPage']) && $_GET['resultsPerPage'] == 12) ? 'selected' : ''; ?>>12</option>
            <option value="18" <?php echo (isset($_GET['resultsPerPage']) && $_GET['resultsPerPage'] == 18) ? 'selected' : ''; ?>>18</option>
        </select>
        <!-- Behalte die aktuellen Filter und Sortieroptionen -->
        <input type="hidden" name="sort" value="<?php echo htmlspecialchars($_GET['sort'] ?? ''); ?>">
        <input type="hidden" name="search" value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
        <input type="hidden" name="nummer" value="<?php echo htmlspecialchars($_GET['nummer'] ?? ''); ?>">
        <input type="hidden" name="autor" value="<?php echo htmlspecialchars($_GET['autor'] ?? ''); ?>">
    </form>
</div>

<div class="book-container">
    <?php
    // Ergebnisse anzeigen
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $bookId = htmlspecialchars($row['id']); // Annahme: Es gibt eine eindeutige ID für jedes Buch
            echo "<div class='book-box'>
                <h3>" . htmlspecialchars($row['Title']) . "</h3>
                <img src='./buch.jpg' id='bild'>
                <p>" . htmlspecialchars($row['autor']) . "</p>
                <p>" . htmlspecialchars($row['nummer']) . "</p>
                <button class='more-button' onclick='openPopup(\"popup-$bookId\")'>Mehr</button>
            </div>";

            // Pop-up für dieses Buch
            echo "<div id='popup-$bookId' class='popup'>
                <div class='popup-content'>
                    <span class='close-btn' onclick='closePopup(\"popup-$bookId\")'>&times;</span>
                    <h2 class='popup-title'>" . htmlspecialchars($row['Title']) . "</h2>
                    <div class='popup-body'>
                        <img src='./buch.jpg' alt='Buchbild' class='popup-image'>
                        <div class='popup-info'>
                            <div class='info-row'>
                                <span>Katalog:</span>
                                <span>" . htmlspecialchars($row['katalog'] ?? 'Nicht verfügbar') . "</span>
                            </div>
                            <div class='info-row'>
                                <span>Kategorie:</span>
                                <span>" . htmlspecialchars($row['kategoriename'] ?? 'Keine Kategorie') . "</span>
                            </div>
                            <div class='info-row'>
                                <span>Zustand:</span>
                                <span>" . htmlspecialchars($row['zustand_beschreibung'] ?? 'Unbekannt') . "</span>
                            </div>
                        </div>
                    </div>
                    <p class='popup-description'>Beschreibung: " . htmlspecialchars($row['Beschreibung'] ?? 'Keine Beschreibung verfügbar') . "</p>
                    <button class='close-popup-button' onclick='closePopup(\"popup-$bookId\")'>Schließen</button>
                </div>
            </div>";
        }
    } else {
        echo "<div>Keine Ergebnisse gefunden.</div>";
    }

    // Pagination-Links
    echo "<div class='pagination'>";

    // Link für 5 Seiten zurück
    if ($currentPage > 5) {
        echo "<a href='?page=" . ($currentPage - 5) . "&sort=" . ($_GET['sort'] ?? '') . "&search=" . ($_GET['search'] ?? '') . "&nummer=" . ($_GET['nummer'] ?? '') . "&autor=" . ($_GET['autor'] ?? '') . "&resultsPerPage=" . ($_GET['resultsPerPage'] ?? '') . "'>« -5</a>";
    }

    // Link für die vorherige Seite
    if ($currentPage > 1) {
        echo "<a href='?page=" . ($currentPage - 1) . "&sort=" . ($_GET['sort'] ?? '') . "&search=" . ($_GET['search'] ?? '') . "&nummer=" . ($_GET['nummer'] ?? '') . "&autor=" . ($_GET['autor'] ?? '') . "&resultsPerPage=" . ($_GET['resultsPerPage'] ?? '') . "'>« Zurück</a>";
    }

    // Seitenlinks (nur 2 Seiten vor und zurück anzeigen)
    $startPage = max(1, $currentPage - 2);
    $endPage = min($totalPages, $currentPage + 2);

    for ($i = $startPage; $i <= $endPage; $i++) {
        if ($i == $currentPage) {
            echo "<span class='current-page'>$i</span>";
        } else {
            echo "<a href='?page=$i&sort=" . ($_GET['sort'] ?? '') . "&search=" . ($_GET['search'] ?? '') . "&nummer=" . ($_GET['nummer'] ?? '') . "&autor=" . ($_GET['autor'] ?? '') . "&resultsPerPage=" . ($_GET['resultsPerPage'] ?? '') . "'>$i</a>";
        }
    }

    // Link für die nächste Seite
    if ($currentPage < $totalPages) {
        echo "<a href='?page=" . ($currentPage + 1) . "&sort=" . ($_GET['sort'] ?? '') . "&search=" . ($_GET['search'] ?? '') . "&nummer=" . ($_GET['nummer'] ?? '') . "&autor=" . ($_GET['autor'] ?? '') . "&resultsPerPage=" . ($_GET['resultsPerPage'] ?? '') . "'>Weiter »</a>";
    }

    // Link für 5 Seiten vor
    if ($currentPage <= $totalPages - 5) {
        echo "<a href='?page=" . ($currentPage + 5) . "&sort=" . ($_GET['sort'] ?? '') . "&search=" . ($_GET['search'] ?? '') . "&nummer=" . ($_GET['nummer'] ?? '') . "&autor=" . ($_GET['autor'] ?? '') . "&resultsPerPage=" . ($_GET['resultsPerPage'] ?? '') . "'>+5 »</a>";
    }

    echo "</div>";

    $conn->close();
    ?>
</div>

</body>
<footer class="footer">
    <p>&copy; <?php echo date("Y"); ?> Books.ch. Alle Rechte vorbehalten.</p>
</footer>
</html>
