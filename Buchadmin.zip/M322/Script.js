function toggleMenu() {
    const menu = document.getElementById('menu');
    const menuIcon = document.querySelector('.menu-icon');

    // Menü ein- oder ausklappen
    menu.classList.toggle('active');

    // Burger-Symbol ausblenden, wenn das Menü aktiv ist
    if (menu.classList.contains('active')) {
        menuIcon.classList.add('hidden');
    } else {
        menuIcon.classList.remove('hidden');
    }
}


function toggleInfo() {
    var container = document.getElementById("infoContainer");
    container.classList.toggle("active");
}

// Öffnet das Pop-up
function openPopup(popupId) {
    document.getElementById(popupId).style.display = 'block';
}

// Schließt das Pop-up
function closePopup(popupId) {
    document.getElementById(popupId).style.display = 'none';
}

document.addEventListener("DOMContentLoaded", () => {
    const infoBox = document.querySelector(".info-box");
    const infoContainer = document.querySelector(".info-container");

    infoBox.addEventListener("click", () => {
        infoContainer.classList.toggle("active"); // Container ein-/ausklappen
        infoBox.classList.toggle("active"); // Chevron drehen
    });
});