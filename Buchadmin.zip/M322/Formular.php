<?php
// Verarbeitung der Formulardaten
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $email = htmlspecialchars($_POST["email"]);
    $message = htmlspecialchars($_POST["message"]);

    // Beispiel: Daten ausgeben oder weiterverarbeiten (z.B. speichern, per E-Mail versenden)
    $output = "<h2>Formular erfolgreich gesendet</h2>";
    $output .= "<p><strong>Name:</strong> " . $name . "</p>";
    $output .= "<p><strong>E-Mail:</strong> " . $email . "</p>";
    $output .= "<p><strong>Nachricht:</strong> " . nl2br($message) . "</p>";
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formularverarbeitung</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        form { max-width: 400px; margin-bottom: 20px; }
        label, input, textarea { display: block; width: 100%; margin-bottom: 10px; }
    </style>
</head>
<body>
    <h1>Kontaktformular</h1>
    
    <form action="" method="post">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">E-Mail:</label>
        <input type="email" id="email" name="email" required>

        <label for="message">Nachricht:</label>
        <textarea id="message" name="message" rows="4" required></textarea>

        <input type="submit" value="Absenden">
    </form>
    
    <?php 
    // Falls Daten verarbeitet wurden, Ausgabe anzeigen
    if (!empty($output)) { 
        echo $output; 
    } 
    ?>
</body>
</html>
