from m5stack import *
from m5stack_ui import *
from uiflow import *
from m5mqtt import M5mqtt
import unit
import time
import random
import _thread

screen = M5Screen()
screen.clean_screen()
screen.set_screen_bg_color(0xFFFFFF)
rfid_0 = unit.get(unit.RFID, unit.PORTA)

def fun_Karim_123_feeds_score1_(topic_data):
  global vergleich
  vergleich = int(topic_data)
  
global m5mqtt

m5mqtt = M5mqtt('adafruit', 'io.adafruit.com', 1883, 'Karim_123', 'aio_qdoC95YrawIEnXrHlzM2Cb0sbcwR', 300)
m5mqtt.start()

# Initialisieren
global vergleich, ausgewählt, score, Hochgeladen, Name
score = 0
ausgewählt = False
Hochgeladen = False


# Konstanten
GRID_SIZE = 10
SNAKE_COLOR = 0x33ff33
FOOD_COLOR = 0xff3333
BACKGROUND_COLOR = 0x000000
TEXT_COLOR = 0xffffff

# Spielfeld
width = lcd.screensize()[0] // GRID_SIZE
height = lcd.screensize()[1] // GRID_SIZE

# Initialisiere Schlange und Essen
snake = [(width // 2, height // 2)]
direction = (1, 0)
food = (random.randint(0, width - 1), random.randint(0, height - 1))

def ending1():
  global ausgewählt, vergleich, score
  vergleich = m5mqtt.subscribe('Karim_123/feeds/score1', fun_Karim_123_feeds_score1_)

  if 0<score:  
    lcd.clear()
    m5mqtt.start()
    m5mqtt.publish(str('Karim_123/feeds/score1'), str(score), 0)
    lcd.print("Hochgeladen",lcd.Center,lcd.CENTER)
    
    wait_ms(5000)
    
    

      
def ending2():
  global ausgewählt, vergleich, score

  
  vergleich = M5mqtt.subscribe('Karim_123/feeds/score2', fun_Karim_123_feeds_score1_,0)
        
  if 0 < score:
    lcd.clear()
    m5mqtt.start()
    m5mqtt.publish(str('Karim_123/Score1'), str(score), 0)
    lcd.print("Hochgeladen",lcd.CENTER,lcd.CENTER)
    lcd.print("Der Highscore ist"(score+13),lcd.CENTER-90,lcd.CENTER)
        
    wait_ms(5000)
        

 
  
    

def endscreen():
  i = 0
  global ausgewählt
  lcd.clear(BACKGROUND_COLOR)
  lcd.print("Game Over", lcd.CENTER, lcd.CENTER, color=0xff0000)
  lcd.print("Score: {}".format(score), lcd.CENTER, lcd.CENTER-90, color=0xff0000)
  
  wait_ms(2000)
  lcd.clear()
  while i == 0:
    i=i+1
    lcd.fill(0x33cc00)
    wait_ms(2000)
    if Name=="Karim":
      ending1()
    elif Name=="Damian":
      ending2()
    else:
      ending1()

def draw_pixel(x, y, color):
    lcd.rect(x * GRID_SIZE, y * GRID_SIZE, GRID_SIZE, GRID_SIZE, color, color)

def draw_snake():
    for segment in snake:
        draw_pixel(segment[0], segment[1], SNAKE_COLOR)

def draw_food():
    draw_pixel(food[0], food[1], FOOD_COLOR)

def draw_score():
    lcd.print('Score: {}'.format(score), 0, 0, color=TEXT_COLOR)

def check_collision():
    head = snake[0]
    if head in snake[1:] or head[0] < 0 or head[0] >= width or head[1] < 0 or head[1] >= height:
        return True
    return False

def update_snake():
    global food, score
    new_head = (snake[0][0] + direction[0], snake[0][1] + direction[1])
    snake.insert(0, new_head)
    if new_head == food:
        score += 1
        food = (random.randint(0, width - 1), random.randint(0, height - 1))
    else:
        snake.pop()

def on_btnA_pressed():
    global direction
    if direction in [(1, 0), (-1, 0)]:  # Horizontal
        if direction != (0, 1):  # Verhindern, dass die Schlange in die entgegengesetzte Richtung geht
            direction = (0, -1)
    elif direction in [(0, 1), (0, -1)]:  # Vertikal
        if direction != (1, 0):  # Verhindern, dass die Schlange in die entgegengesetzte Richtung geht
            direction = (-1, 0)

def on_btnB_pressed():
    global direction
    if direction in [(1, 0), (-1, 0)]:  # Horizontal
        if direction != (0, -1):  # Verhindern, dass die Schlange in die entgegengesetzte Richtung geht
            direction = (0, 1)
    elif direction in [(0, 1), (0, -1)]:  # Vertikal
        if direction != (-1, 0):  # Verhindern, dass die Schlange in die entgegengesetzte Richtung geht
            direction = (1, 0)

btnA.wasPressed(on_btnA_pressed)
btnB.wasPressed(on_btnB_pressed)

# Hauptschleife
while True:
    if Hochgeladen==True:
        lcd.clear(BACKGROUND_COLOR)
        update_snake()
        if check_collision():
            endscreen()
        draw_snake()
        draw_food()
        draw_score()
        wait_ms(200)
    else:
        lcd.print("Wer spielt?", lcd.CENTER, lcd.CENTER, color=0xff0000)
        if rfid_0.isCardOn():
            Name = rfid_0.readBlockStr(1)
            vergleich = 0
            Hochgeladen = True









